
#include "simba.h"

const FAR char sysinfo[] = "app:    myapp built - by -.\r\n"
                           "board:  arduino_pro_micro\r\n"
                           "mcu:    atmega32u4\r\n";
