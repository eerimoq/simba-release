
#include "simba.h"

const FAR char sysinfo[] = "app:    myapp built - by -.\r\n"
                           "board:  arduino_nano\r\n"
                           "mcu:    atmega328p\r\n";
