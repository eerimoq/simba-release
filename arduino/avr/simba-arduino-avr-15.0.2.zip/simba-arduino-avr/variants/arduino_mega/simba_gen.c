
#include "simba.h"

const FAR char sysinfo[] = "app:    myapp built - by -.\r\n"
                           "board:  arduino_mega\r\n"
                           "mcu:    atmega2560\r\n";
