
#ifndef __SETTINGS_H__
#define __SETTINGS_H__

#define SETTING_AREA_OFFSET     128
#define SETTING_AREA_SIZE       256
#define SETTING_AREA_CRC_OFFSET (SETTING_AREA_SIZE - 4)

#endif
