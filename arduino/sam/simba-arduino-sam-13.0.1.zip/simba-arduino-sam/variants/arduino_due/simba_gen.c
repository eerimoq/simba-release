
#include "simba.h"

const FAR char sysinfo[] = "app:    myapp built - by -.\r\n"
                           "board:  arduino_due\r\n"
                           "mcu:    sam3x8e\r\n";
