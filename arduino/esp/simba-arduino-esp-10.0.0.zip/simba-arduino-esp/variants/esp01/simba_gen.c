
#include "simba.h"

const FAR char sysinfo[] = "app:    myapp built - by -.\r\n"
                           "board:  esp01\r\n"
                           "mcu:    esp8266\r\n";
