
#include "simba.h"

const FAR char sysinfo[] = "app:    myapp built - by -.\r\n"
                           "board:  esp12e\r\n"
                           "mcu:    esp8266\r\n";
