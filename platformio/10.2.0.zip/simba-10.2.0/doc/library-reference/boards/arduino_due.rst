:mod:`arduino_due` --- Arduino Due
==================================

.. module:: arduino_due
   :synopsis: Arduino Due.

Source code: :github-blob:`src/boards/arduino_due/board.h`, :github-blob:`src/boards/arduino_due/board.c`

Hardware reference: :doc:`Arduino Due <../../boards/arduino_due>`

----------------------------------------------

.. doxygenfile:: boards/arduino_due/board.h
   :project: simba
