:mod:`arduino_pro_micro` --- Arduino Pro Micro
==============================================

.. module:: arduino_pro_micro
   :synopsis: Arduino Pro Micro.

Source code: :github-blob:`src/boards/arduino_pro_micro/board.h`, :github-blob:`src/boards/arduino_pro_micro/board.c`

Hardware reference: :doc:`Arduino Pro Micro<../../boards/arduino_pro_micro>`

----------------------------------------------

.. doxygenfile:: boards/arduino_pro_micro/board.h
   :project: simba
