:mod:`arduino_nano` --- Arduino Nano
====================================

.. module:: arduino_nano
   :synopsis: Arduino Nano.

Source code: :github-blob:`src/boards/arduino_nano/board.h`, :github-blob:`src/boards/arduino_nano/board.c`

Hardware reference: :doc:`Arduino Nano <../../boards/arduino_nano>`

----------------------------------------------

.. doxygenfile:: boards/arduino_nano/board.h
   :project: simba
