Enter the bootloader
--------------------

Recover a bricked board by entering the bootloader.

1. Power up the board.

2. Connect RST to GND for a second to enter the bootloader and stay in
   it for 8 seconds.
