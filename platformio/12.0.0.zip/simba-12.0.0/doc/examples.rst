Examples
========

Below is a list of simple examples that are useful to understand the
basics of `Simba`.

There are a lot more :github-tree:`examples<examples>` and
:github-tree:`unit tests<tst>` on Github that shows how to use most of
the `Simba` modules.

.. toctree::
   :maxdepth: 1
   :glob:   

   examples/*
