:mod:`heap` --- Heap
=================================

.. module:: heap
   :synopsis: Heap.

Source code: :github-blob:`src/alloc/heap.h`, :github-blob:`src/alloc/heap.c`

Test code: :github-blob:`tst/alloc/heap/main.c`

Test coverage: :codecov:`src/alloc/heap.c`

----------------------------------------------

.. doxygenfile:: alloc/heap.h
   :project: simba
