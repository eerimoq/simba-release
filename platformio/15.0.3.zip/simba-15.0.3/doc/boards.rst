Boards
======

The boards supported by `Simba`.

.. toctree::
   :glob:
   :titlesonly:
   :maxdepth: 1

   boards/*
