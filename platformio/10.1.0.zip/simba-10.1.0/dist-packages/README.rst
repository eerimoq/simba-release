Directory of installed packages.
