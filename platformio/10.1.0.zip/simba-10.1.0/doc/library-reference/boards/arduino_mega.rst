:mod:`arduino_mega` --- Arduino Mega
====================================

.. module:: arduino_mega
   :synopsis: Arduino Mega.

Source code: :github-blob:`src/boards/arduino_mega/board.h`, :github-blob:`src/boards/arduino_mega/board.c`

Hardware reference: :doc:`Arduino Mega <../../boards/arduino_mega>`

----------------------------------------------

.. doxygenfile:: boards/arduino_mega/board.h
   :project: simba
