alloc
=====

Memory management is the act of managing computer memory. The
essential requirement of memory management is to provide ways to
dynamically allocate portions of memory to programs at their request,
and free it for reuse when no longer needed.

The alloc package on :github-tree:`Github<src/alloc>`.

.. toctree::
   :glob:   
   :titlesonly:

   alloc/*
