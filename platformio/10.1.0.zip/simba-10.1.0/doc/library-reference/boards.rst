boards
======

The boards supported by `Simba`.

The boards on :github-tree:`Github<src/boards>`.

.. toctree::
   :glob:   
   :maxdepth: 1

   boards/*
