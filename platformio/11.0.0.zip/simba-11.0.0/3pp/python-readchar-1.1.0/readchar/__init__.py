__version__ = '1.1.0'

from .readchar import readchar, readkey
from . import key

__all__ = [readchar, readkey, key]
